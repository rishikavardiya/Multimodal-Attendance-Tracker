"""
AttendAI backend
----------------
FastAPI API for the AttendAI Multimodal Attendance & Engagement prototype.

Important:
- This prototype does not identify people, recognize faces, or infer emotions.
- Video analysis checks basic image quality only.
- Audio analysis measures signal level only; optional transcript text can be
  supplied by the browser SpeechRecognition API.
- Attendance decisions must be reviewed by a human.
"""

import os
import io
import csv
import sqlite3
import wave
import math
import struct
from datetime import datetime, timezone
from typing import Optional

from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from PIL import Image

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.getenv("ATTEND_AI_DB", os.path.join(APP_DIR, "attendai.db"))

app = FastAPI(
    title="AttendAI Backend",
    description="Backend APIs for attendance sessions, signal analysis and learning insights.",
    version="1.0.0",
)

# Configure FRONTEND_ORIGINS in production, e.g.
# FRONTEND_ORIGINS=https://rishikavardiya.github.io
origins_env = os.getenv("FRONTEND_ORIGINS", "*")
allowed_origins = [x.strip() for x in origins_env.split(",") if x.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                host TEXT DEFAULT 'Host',
                started_at TEXT NOT NULL,
                ended_at TEXT,
                status TEXT NOT NULL DEFAULT 'active'
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS attendance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER NOT NULL,
                student_name TEXT NOT NULL,
                student_id TEXT,
                status TEXT NOT NULL DEFAULT 'present',
                marked_at TEXT NOT NULL,
                FOREIGN KEY(session_id) REFERENCES sessions(id)
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS analyses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER,
                analysis_type TEXT NOT NULL,
                result_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        conn.commit()


init_db()


def now_iso():
    return datetime.now(timezone.utc).isoformat()


class SessionCreate(BaseModel):
    title: str = Field(min_length=1, max_length=150)
    host: str = Field(default="Host", max_length=100)


class AttendanceCreate(BaseModel):
    student_name: str = Field(min_length=1, max_length=120)
    student_id: Optional[str] = Field(default=None, max_length=80)
    status: str = Field(default="present", pattern="^(present|absent|late)$")


class StudentInsightRequest(BaseModel):
    student_name: str = Field(min_length=1, max_length=120)
    learning_goal: str = Field(min_length=1, max_length=200)
    attendance_percentage: Optional[float] = Field(default=None, ge=0, le=100)
    engagement_percentage: Optional[float] = Field(default=None, ge=0, le=100)


class TranscriptRequest(BaseModel):
    session_id: Optional[int] = None
    transcript: str = Field(min_length=1, max_length=10000)


class ReportRequest(BaseModel):
    session_id: int


@app.get("/")
def root():
    return {
        "message": "AttendAI backend is running",
        "docs": "/docs",
        "privacy": "No identity recognition or emotion recognition is performed."
    }


@app.get("/health")
def health():
    return {"status": "ok", "timestamp": now_iso()}


@app.post("/api/sessions", status_code=201)
def create_session(payload: SessionCreate):
    with get_db() as conn:
        cur = conn.execute(
            "INSERT INTO sessions (title, host, started_at, status) VALUES (?, ?, ?, 'active')",
            (payload.title, payload.host, now_iso()),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM sessions WHERE id = ?", (cur.lastrowid,)).fetchone()
    return dict(row)


@app.get("/api/sessions")
def list_sessions():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM sessions ORDER BY id DESC").fetchall()
    return [dict(row) for row in rows]


@app.get("/api/sessions/{session_id}")
def get_session(session_id: int):
    with get_db() as conn:
        row = conn.execute("SELECT * FROM sessions WHERE id = ?", (session_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Session not found")
        attendance = conn.execute(
            "SELECT * FROM attendance WHERE session_id = ? ORDER BY id DESC",
            (session_id,),
        ).fetchall()
    result = dict(row)
    result["attendance"] = [dict(item) for item in attendance]
    return result


@app.post("/api/sessions/{session_id}/end")
def end_session(session_id: int):
    with get_db() as conn:
        cur = conn.execute(
            "UPDATE sessions SET ended_at = ?, status = 'ended' WHERE id = ? AND status = 'active'",
            (now_iso(), session_id),
        )
        conn.commit()
        if cur.rowcount == 0:
            exists = conn.execute("SELECT id FROM sessions WHERE id = ?", (session_id,)).fetchone()
            if not exists:
                raise HTTPException(status_code=404, detail="Session not found")
        row = conn.execute("SELECT * FROM sessions WHERE id = ?", (session_id,)).fetchone()
    return dict(row)


@app.post("/api/sessions/{session_id}/attendance", status_code=201)
def add_attendance(session_id: int, payload: AttendanceCreate):
    with get_db() as conn:
        exists = conn.execute("SELECT id FROM sessions WHERE id = ?", (session_id,)).fetchone()
        if not exists:
            raise HTTPException(status_code=404, detail="Session not found")
        cur = conn.execute(
            """INSERT INTO attendance
               (session_id, student_name, student_id, status, marked_at)
               VALUES (?, ?, ?, ?, ?)""",
            (session_id, payload.student_name, payload.student_id, payload.status, now_iso()),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM attendance WHERE id = ?", (cur.lastrowid,)).fetchone()
    return dict(row)


@app.get("/api/attendance")
def attendance_records(session_id: Optional[int] = None):
    query = """
        SELECT a.*, s.title AS session_title
        FROM attendance a JOIN sessions s ON s.id = a.session_id
    """
    params = ()
    if session_id is not None:
        query += " WHERE a.session_id = ?"
        params = (session_id,)
    query += " ORDER BY a.marked_at DESC"
    with get_db() as conn:
        rows = conn.execute(query, params).fetchall()
    return [dict(row) for row in rows]


@app.get("/api/attendance/export.csv")
def export_attendance_csv():
    with get_db() as conn:
        rows = conn.execute("""
            SELECT a.student_name, a.student_id, a.status, a.marked_at, s.title AS session
            FROM attendance a JOIN sessions s ON s.id = a.session_id
            ORDER BY a.marked_at DESC
        """).fetchall()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Student Name", "Student ID", "Status", "Marked At", "Session"])
    for row in rows:
        writer.writerow([row["student_name"], row["student_id"], row["status"],
                         row["marked_at"], row["session"]])
    output.seek(0)
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=attendai_attendance.csv"},
    )


@app.post("/api/analysis/video")
async def analyze_video_frame(
    file: UploadFile = File(...),
    session_id: Optional[int] = Form(default=None),
):
    """Check image dimensions and brightness; does not identify people."""
    if file.content_type not in ("image/jpeg", "image/png", "image/webp"):
        raise HTTPException(status_code=415, detail="Upload a JPG, PNG or WEBP image.")
    raw = await file.read()
    if len(raw) > 8 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Image must be smaller than 8 MB.")
    try:
        image = Image.open(io.BytesIO(raw)).convert("RGB")
    except Exception:
        raise HTTPException(status_code=400, detail="Could not read the image.")

    width, height = image.size
    sample = image.resize((min(width, 100), min(height, 100)))
    pixels = list(sample.getdata())
    brightness = round(sum((r + g + b) / 3 for r, g, b in pixels) / max(len(pixels), 1), 1)
    quality = "good" if width >= 320 and height >= 240 and 35 <= brightness <= 225 else "needs_review"
    result = {
        "analysis_type": "image_quality",
        "width": width,
        "height": height,
        "average_brightness": brightness,
        "quality": quality,
        "message": "Image quality check only. No face, identity, or emotion recognition."
    }
    save_analysis(session_id, "video", result)
    return result


@app.post("/api/analysis/audio")
async def analyze_audio_file(
    file: UploadFile = File(...),
    session_id: Optional[int] = Form(default=None),
):
    """Measure WAV audio signal level. Does not analyze speaker identity or emotion."""
    raw = await file.read()
    if len(raw) > 15 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Audio must be smaller than 15 MB.")
    try:
        with wave.open(io.BytesIO(raw), "rb") as wav:
            channels = wav.getnchannels()
            sample_width = wav.getsampwidth()
            frame_rate = wav.getframerate()
            frames = wav.readframes(wav.getnframes())
            duration = round(wav.getnframes() / float(frame_rate), 2)
            if not frames:
                rms = 0
            else:
                # Calculate RMS without audioop (removed in Python 3.13).
                if sample_width == 1:
                    samples = [b - 128 for b in frames]
                elif sample_width == 2:
                    count = len(frames) // 2
                    samples = struct.unpack("<" + "h" * count, frames[:count * 2])
                elif sample_width == 4:
                    count = len(frames) // 4
                    samples = struct.unpack("<" + "i" * count, frames[:count * 4])
                elif sample_width == 3:
                    samples = []
                    for i in range(0, len(frames) - 2, 3):
                        value = int.from_bytes(frames[i:i+3], "little", signed=False)
                        if value & 0x800000:
                            value -= 1 << 24
                        samples.append(value)
                else:
                    raise ValueError("Unsupported WAV sample width")
                rms = int(math.sqrt(sum(x * x for x in samples) / len(samples))) if samples else 0
    except Exception:
        raise HTTPException(
            status_code=400,
            detail="This demo endpoint accepts PCM WAV audio. Convert other formats to WAV first."
        )
    result = {
        "analysis_type": "audio_signal",
        "duration_seconds": duration,
        "sample_rate": frame_rate,
        "channels": channels,
        "rms_signal_level": rms,
        "signal_available": rms > 0,
        "message": "Signal-level measurement only; no voice identity, emotion, or sentiment analysis."
    }
    save_analysis(session_id, "audio", result)
    return result


def save_analysis(session_id, analysis_type, result):
    import json
    with get_db() as conn:
        conn.execute(
            "INSERT INTO analyses (session_id, analysis_type, result_json, created_at) VALUES (?, ?, ?, ?)",
            (session_id, analysis_type, json.dumps(result), now_iso()),
        )
        conn.commit()


@app.post("/api/analysis/transcript")
def save_transcript(payload: TranscriptRequest):
    """Store text explicitly supplied by the browser speech-to-text feature."""
    result = {
        "transcript": payload.transcript,
        "word_count": len(payload.transcript.split()),
        "message": "Transcript text supplied by the client; review before relying on it."
    }
    save_analysis(payload.session_id, "transcript", result)
    return result


@app.post("/api/engagement/estimate")
def estimate_engagement(video_signal: bool = False, audio_signal: bool = False):
    """Transparent availability score, not a validated attention measurement."""
    available = int(video_signal) + int(audio_signal)
    score = round((available / 2) * 100)
    return {
        "signal_availability_percentage": score,
        "video_signal_available": video_signal,
        "audio_signal_available": audio_signal,
        "interpretation": (
            "Both signals available" if available == 2 else
            "One signal available" if available == 1 else
            "No signals available"
        ),
        "warning": "This is not a validated engagement, attention, emotion, or learning score."
    }


@app.post("/api/student-insights")
def student_insights(payload: StudentInsightRequest):
    goal = payload.learning_goal.lower()
    suggestions = {
        "understanding concepts": [
            "Review one key concept after class.",
            "Try explaining the concept in your own words.",
            "Solve two practice questions."
        ],
        "improving participation": [
            "Prepare one question before the next session.",
            "Contribute at least once during discussion.",
            "Use short polls to check understanding."
        ],
        "exam preparation": [
            "Create a short revision plan.",
            "Practice questions under timed conditions.",
            "Review mistakes and revisit weak topics."
        ],
        "improving consistency": [
            "Set a regular study schedule.",
            "Break learning into short daily tasks.",
            "Review progress at the end of each week."
        ]
    }
    matched = next((v for k, v in suggestions.items() if k in goal), None)
    if matched is None:
        matched = [
            "Break your learning goal into small weekly targets.",
            "Review your progress after each session.",
            "Ask your teacher for feedback on difficult topics."
        ]
    return {
        "student_name": payload.student_name,
        "learning_goal": payload.learning_goal,
        "attendance_percentage": payload.attendance_percentage,
        "engagement_percentage": payload.engagement_percentage,
        "suggestions": matched,
        "note": "Rule-based learning support, not an automated academic decision."
    }


@app.get("/api/agent/recommendations")
def recommendations():
    return {
        "recommendations": [
            "Start with a quick check-in question.",
            "Use a short poll during class.",
            "Leave time for learner questions.",
            "Review attendance exceptions manually."
        ]
    }


@app.post("/api/reports")
def generate_report(payload: ReportRequest):
    with get_db() as conn:
        session = conn.execute(
            "SELECT * FROM sessions WHERE id = ?", (payload.session_id,)
        ).fetchone()
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        records = conn.execute(
            "SELECT status, COUNT(*) AS total FROM attendance WHERE session_id = ? GROUP BY status",
            (payload.session_id,),
        ).fetchall()
        analyses = conn.execute(
            "SELECT analysis_type, result_json, created_at FROM analyses WHERE session_id = ? ORDER BY id",
            (payload.session_id,),
        ).fetchall()

    counts = {row["status"]: row["total"] for row in records}
    total = sum(counts.values())
    present = counts.get("present", 0)
    return {
        "session": dict(session),
        "attendance": {
            "total_records": total,
            "present": present,
            "absent": counts.get("absent", 0),
            "late": counts.get("late", 0),
            "presence_percentage": round((present / total) * 100, 1) if total else 0
        },
        "analyses": [
            {"type": row["analysis_type"], "result": row["result_json"], "created_at": row["created_at"]}
            for row in analyses
        ],
        "generated_at": now_iso(),
        "review_note": "Prototype report. A teacher/host must verify attendance before final decisions."
    }


@app.get("/api/reports/{session_id}/download")
def download_report(session_id: int):
    with get_db() as conn:
        session = conn.execute("SELECT * FROM sessions WHERE id = ?", (session_id,)).fetchone()
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        rows = conn.execute(
            "SELECT student_name, student_id, status, marked_at FROM attendance WHERE session_id = ?",
            (session_id,),
        ).fetchall()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Session", "Student Name", "Student ID", "Status", "Marked At"])
    for row in rows:
        writer.writerow([session["title"], row["student_name"], row["student_id"],
                         row["status"], row["marked_at"]])
    output.seek(0)
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="attendai_session_{session_id}_report.csv"'},
    )
