# AttendAI Backend

Python FastAPI backend for the AttendAI Multimodal Attendance & Engagement prototype.

## Files
- `main.py` — API and SQLite database logic
- `requirements.txt` — Python packages

## Run locally (Windows)
```bash
py -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload
```

Open:
- API status: http://127.0.0.1:8000/health
- Interactive API docs: http://127.0.0.1:8000/docs

## Main endpoints
- `POST /api/sessions` — create a session
- `GET /api/sessions` — list sessions
- `POST /api/sessions/{id}/end` — end a session
- `POST /api/sessions/{id}/attendance` — add attendance
- `GET /api/attendance` — attendance records
- `GET /api/attendance/export.csv` — export attendance CSV
- `POST /api/analysis/video` — image-quality check (multipart file)
- `POST /api/analysis/audio` — WAV signal-level analysis (multipart file)
- `POST /api/analysis/transcript` — save browser-provided transcript text
- `POST /api/engagement/estimate` — signal-availability estimate
- `POST /api/student-insights` — rule-based learning suggestions
- `GET /api/agent/recommendations` — recommendations
- `POST /api/reports` — generate session report JSON
- `GET /api/reports/{id}/download` — download session CSV

## Connect the GitHub Pages frontend
GitHub Pages cannot run Python. Deploy this backend separately (for example, on a Python web host), then update frontend JavaScript to call the deployed API base URL using `fetch()`.

For local testing, use `http://127.0.0.1:8000`. When deploying, set:
```text
FRONTEND_ORIGINS=https://rishikavardiya.github.io
```
Set `ATTEND_AI_DB` to a persistent writable database path if your hosting platform supports persistent disks.

## Important prototype limitations
- This is a starter backend; your current static website does not automatically call these APIs.
- SQLite is suitable for a prototype. For a multi-user production system, use PostgreSQL and add authentication, authorization, backups, rate limiting, and audit logs.
- Video endpoint checks image dimensions/brightness only. It does not perform face recognition or identity verification.
- Audio endpoint currently accepts PCM WAV files and measures signal strength only. It does not identify speakers or infer emotion.
- Browser camera/microphone access remains controlled by the user's browser permissions. Avoid uploading media unless the user explicitly consents.
- Attendance and learning recommendations should be reviewed by a teacher/host.
